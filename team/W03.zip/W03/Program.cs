﻿using System;

namespace W03
{
    class MainClass
    {
        public static void Main(string[] args)
        {

             MngMenu _mymenu = new MngMenu();
             MngPrompt _mngPrompt = new MngPrompt();
             // TypePrompt _resp = _mngPrompt.getPropertiesById("3");

            while (_mymenu.doWhile())
            {
            }

            Console.WriteLine("End of program!!!");
        }
    }
}
