﻿using System;
namespace W03
{
    public interface ActionInterface
    {

        int Action(ref MngJornal jornal);
    }
}
